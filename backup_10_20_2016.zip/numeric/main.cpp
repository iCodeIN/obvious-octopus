#include <iostream>
#include <string>
#include <map>

#include "distribution.hpp"

using namespace std;
using namespace numeric;

int main()
{
   map<string, int> fruits;
   fruits["apple"] = 2;
   fruits["banana"] = 4;
   fruits["citrus"] = 8;
   fruits["dragon fruit"] = 16;
   
   auto temp = numeric::Distribution<string>::makeRelative(fruits);
   auto temp2 = numeric::Distribution<string>::left(temp, 0.33);

   for(auto p : temp2)
   {
      cout << p.first << "\t" << p.second << endl;
   }
   return 0;
}
