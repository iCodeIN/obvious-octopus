var searchData=
[
  ['realfunctiontype',['RealFunctionType',['../classnumeric_1_1Derivative.html#a9ae94b40e81041335af21a764eceaa19',1,'numeric::Derivative']]],
  ['relativedistributiontype',['RelativeDistributionType',['../classnumeric_1_1Distribution.html#a433b9d2922d8ded4afe2cc691bd96e6d',1,'numeric::Distribution']]],
  ['rgbcolor',['RGBColor',['../classSVG_1_1HSV.html#a93da59189b0174379bf7033229c8096d',1,'SVG::HSV']]]
];
