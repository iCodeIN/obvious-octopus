var searchData=
[
  ['layout',['layout',['../classgraphUI_1_1AbstractGraphLayout.html#aa4512547673bb81e74f800fdd9b451b8',1,'graphUI::AbstractGraphLayout']]],
  ['line',['Line',['../classSVG_1_1Line.html#acb0e1260c85b3037a2c35cbece03cf2e',1,'SVG::Line::Line(int x1, int y1, int x2, int y2)'],['../classSVG_1_1Line.html#a3d423fefc377e9220e124e960cf62bba',1,'SVG::Line::Line(const Line &amp;)=delete'],['../classSVG_1_1Line.html#af9a1c3683d0c5d8005207efa16d500ba',1,'SVG::Line::Line(Line &amp;)=delete']]],
  ['lineplot',['LinePlot',['../classplotting_1_1LinePlot.html#aef22889a9d4ba4b7e011610b1d0cecb9',1,'plotting::LinePlot::LinePlot(int w, int h)'],['../classplotting_1_1LinePlot.html#aab654ebe50838fb4b181096b7412fa44',1,'plotting::LinePlot::LinePlot(LinePlot &amp;n)=delete'],['../classplotting_1_1LinePlot.html#ac9c8d0e456cc1ab5b74ae9d366a6d6d7',1,'plotting::LinePlot::LinePlot(const LinePlot &amp;n)=delete']]]
];
