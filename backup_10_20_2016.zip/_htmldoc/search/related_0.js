var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../classSVG_1_1IElement.html#a4b8fdacb65b595c3a32b7bac1075c42a',1,'SVG::IElement::operator&lt;&lt;()'],['../classXML_1_1Element.html#ada5f7d09224633d40dd5621742f1b9b4',1,'XML::Element::operator&lt;&lt;()']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../classXML_1_1Element.html#a8b793a7d0cc34274210f5f0a6883fb97',1,'XML::Element']]]
];
