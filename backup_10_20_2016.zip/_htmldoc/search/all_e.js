var searchData=
[
  ['randtuple',['randTuple',['../classmeta_1_1AbstractMetaHeuristic.html#ac46986262254c98890b14ace7205a422',1,'meta::AbstractMetaHeuristic']]],
  ['realfunctiontype',['RealFunctionType',['../classnumeric_1_1Derivative.html#a9ae94b40e81041335af21a764eceaa19',1,'numeric::Derivative']]],
  ['rectangle',['Rectangle',['../classSVG_1_1Rectangle.html',1,'SVG']]],
  ['rectangle',['Rectangle',['../classSVG_1_1Rectangle.html#a4e8d590057b1dd6770a3eac6818c164e',1,'SVG::Rectangle::Rectangle(int x, int y, int width, int height)'],['../classSVG_1_1Rectangle.html#a1bab6b6f06a5e33988b5ca1b0b25684e',1,'SVG::Rectangle::Rectangle(int x, int y, int width, int height, int rx, int ry)'],['../classSVG_1_1Rectangle.html#ab27aff61cdd9fb58f5d388741efaf2f8',1,'SVG::Rectangle::Rectangle(const Rectangle &amp;)=delete'],['../classSVG_1_1Rectangle.html#a450aaf0ec6200b44150d43e38b1197ec',1,'SVG::Rectangle::Rectangle(Rectangle &amp;)=delete']]],
  ['relativedistributiontype',['RelativeDistributionType',['../classnumeric_1_1Distribution.html#a433b9d2922d8ded4afe2cc691bd96e6d',1,'numeric::Distribution']]],
  ['remove',['remove',['../classXML_1_1Element.html#a83f191ed5410a66b4a2c4df1e43cd688',1,'XML::Element']]],
  ['render',['render',['../classMazeDrawer.html#aff1b029c8b12875f3243003f1d415d67',1,'MazeDrawer::render()'],['../classplotting_1_1AreaPlot.html#a40b7e31233e7db3a0ab38b8bf51e90e9',1,'plotting::AreaPlot::render()'],['../classplotting_1_1HeatPlot.html#a8f1179899a6d0d12e12d27c0273d0560',1,'plotting::HeatPlot::render()'],['../classplotting_1_1LinePlot.html#a238cd5b3f7c1b600848b72f8016ef851',1,'plotting::LinePlot::render()']]],
  ['rgbcolor',['RGBColor',['../classSVG_1_1HSV.html#a93da59189b0174379bf7033229c8096d',1,'SVG::HSV']]],
  ['rotate',['rotate',['../classSVG_1_1IElement.html#a12c55824cf66163c4c13894e1fc79a03',1,'SVG::IElement::rotate(double a)'],['../classSVG_1_1IElement.html#a4350371dbfb0552e2b2e7f0fa21355de',1,'SVG::IElement::rotate(double a, double x, double y)']]],
  ['rows',['rows',['../classmatrix_1_1BoostMatrixImpl.html#abbe9a2c8e9aa57a80e0f35a71f0c8e06',1,'matrix::BoostMatrixImpl::rows()'],['../classmatrix_1_1IMatrix.html#a4194cbc5b5bfc23d7ffdb839ae6c93c8',1,'matrix::IMatrix::rows()']]]
];
