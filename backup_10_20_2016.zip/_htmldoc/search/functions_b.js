var searchData=
[
  ['neighbour',['neighbour',['../classmeta_1_1AbstractMetaHeuristic.html#ac790357e744c70f7e248b34c6ea7be95',1,'meta::AbstractMetaHeuristic']]],
  ['nextprime',['nextPrime',['../classnumeric_1_1Prime.html#af9afe0d09423b69fb13b7d841d48d2fd',1,'numeric::Prime']]]
];
