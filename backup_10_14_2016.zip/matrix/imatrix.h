#pragma once
#ifndef IMATRIX_HPP
#define IMATRIX_HPP

#include <functional>
#include <memory>

namespace matrix
{
    /*! In mathematics, a matrix (plural matrices) is a rectangular array of numbers, symbols, or expressions, arranged in rows and columns. The individual items in a matrix are called its elements or entries.[4] Provided that they are the same size (have the same number of rows and the same number of columns), two matrices can be added or subtracted element by element. The rule for matrix multiplication, however, is that two matrices can be multiplied only when the number of columns in the first equals the number of rows in the second. Any matrix can be multiplied element-wise by a scalar from its associated field. A major application of matrices is to represent linear transformations, that is, generalizations of linear functions.
     */
    class IMatrix
    {
        public:

            explicit IMatrix() = default;
            virtual ~IMatrix() = default;

            /*! Prohibit const copy constructor
             */
            IMatrix(const IMatrix&) = delete;

            /*! Prohibit copy constructor
             */
            IMatrix(IMatrix&) = delete;

            /*! Prohibit const assignment operator
             */
            void operator=(const IMatrix&) = delete;

            /*! Prohibit assignment operator
             */
            void operator=(IMatrix&) = delete;

            /*! \return the number of rows in this IMatrix
             */
            virtual int rows() const = 0;

            /*! \return the number of columns in this IMatrix
             */
            virtual int cols() const = 0;

            /*! \return the value at position [r,c]
             */
            virtual double get(int r, int c) const = 0;

            /*! set the value at position [r,c]
                \param[in] r the row index
                \param[in] c the column index
                \param[in] d the value
             */
            virtual void set(int r, int c, double d) = 0;

            /*! swap two rows in this IMatrix
               \param[in] r0 the first row index
               \param[in] r1 the second row index
             */
            virtual void swapRows(int r0, int r1) = 0;

            /*! Apply an operator to given MatrixType
            	 \param[in] op			the operator to apply
             */
            virtual void apply(const std::function<double(int row, int col)> &op) = 0;

            /*! \return the largest element in the IMatrix
             */
            virtual double max() const;

            /*! \return the smallest element in the IMatrix
             */
            virtual double min() const;

            /*! \return the transposed IMatrix
             */
            virtual std::unique_ptr<IMatrix> transpose() const = 0;

            /*! \return the result of multiplying this IMatrix with another IMatrix
             */
            virtual std::unique_ptr<IMatrix> mul(const IMatrix &m) const = 0;

    };
}

#endif // IMATRIX_HPP
