#pragma once
#ifndef BOOST_MATRIX_ADAPTER_H
#define BOOST_MATRIX_ADAPTER_H

#include "imatrix.h"

#include <assert.h>
#include <memory>
#include <stdlib.h>
#include <time.h>

#include <boost/numeric/ublas/matrix.hpp>

namespace matrix
{
    class Matrix : public IMatrix
    {
        public:
            using MatrixStorageType = boost::numeric::ublas::matrix<double>;

            /*!
             */
            explicit Matrix(int r, int c)
            {
                m_data(r,c);
                assert(r > 0 && c > 0);
            }
            virtual ~Matrix() = default;

            // --- IMatrix ---
            virtual int rows() const override
            {
                return m_data.size1();
            }

            // --- IMatrix ---
            virtual int cols() const override
            {
                return m_data.size2();
            }

            // --- IMatrix
            virtual double get(int r, int c) const override
            {
                assert(r >= 0 && r < rows() && c >= 0 && c < cols());
                return m_data(r,c);
            }

            // --- IMatrix ---
            virtual void set(int r, int c, double d) override
            {
                assert(r >= 0 && r < rows() && c >= 0 && c < cols());
                m_data(r,c) = d;
            }

            // --- IMatrix ---
            virtual void swapRows(int r0, int r1) override
            {
                assert(r0 >= 0 && r0 < rows() && r1 >= 0 && r1 < rows());
                if(r0 == r1)
                {
                    return;
                }
                double temp;
                for(int i = 0 ; i < cols() ; i++)
                {
                    temp = get(r0, i);
                    set(r0, i, get(r1, i));
                    set(r1, i, temp);
                }
            }

            // --- IMatrix ---
            virtual void apply(const std::function<double(int row, int col)>& op) override
            {
                for(int i=0; i<rows(); i++)
                {
                    for(int j=0; j<cols(); j++)
                    {
                        set(i, j, op(i,j));
                    }
                }
            }

            // --- IMatrix ---
            virtual double max() const override
            {
                auto temp = get(0, 0);
                for(int i=0; i<rows(); i++)
                {
                    for(int j=0; j<cols(); j++)
                    {
                        temp = get(i, j) > temp ? get(i, j) : temp;
                    }
                }
                return temp;
            }

            // --- IMatrix ---
            virtual double min() const override
            {
                auto temp = get(0, 0);
                for(int i=0; i<rows(); i++)
                {
                    for(int j=0; j<cols(); j++)
                    {
                        temp = get(i, j) < temp ? get(i, j) : temp;
                    }
                }
                return temp;
            }

            // --- IMatrix ---
            virtual std::unique_ptr<IMatrix> transpose() const override
            {
                auto matrixPtr = std::unique_ptr<Matrix>(new Matrix(cols(),rows()));
                matrixPtr.get()->m_data = boost::numeric::ublas::trans(m_data);
                return std::move(matrixPtr);
            }

            // --- IMatrix ---
            virtual std::unique_ptr<IMatrix> mul(const IMatrix &m) const override
            {
                auto mPtr = static_cast<const Matrix*>(&m);
                assert(mPtr != nullptr);
                assert(cols() == m.rows());
                auto matrixPtr = new Matrix(m.rows(), m.cols());
                matrixPtr->m_data = boost::numeric::ublas::prod(m_data, mPtr->m_data);
                return std::unique_ptr<IMatrix>(matrixPtr);
            }

        private:
            // --- members ---
            MatrixStorageType m_data;
    };

    /*! \return a Matrix initialized by an std::vector<std::vector<double>>
     */
    static std::unique_ptr<Matrix> matrix(const std::vector<std::vector<double>>& vals)
    {
        int rows = vals.size();
        assert(rows > 0);

        int cols = vals[0].size();
        assert(cols > 0);
        for(int i=0; i<rows; i++)
        {
            assert(vals[i].size() == cols);
        }

        auto matrixPtr = std::unique_ptr<Matrix>(new Matrix(rows, cols));
        auto &matrixRef = *(matrixPtr.get());
        for(int i=0; i<rows; i++)
        {
            for(int j=0; j<cols; j++)
            {
                matrixRef.set(i, j, vals[i][j]);
            }
        }

        return matrixPtr;
    }

    /*! \return an Identity Matrix of size n x n
    	 \param[in] n 	size of the Identity Matrix
     */
    static std::unique_ptr<Matrix> eye(const int n)
    {
        auto matrixPtr = std::unique_ptr<Matrix>(new Matrix(n, n));
        auto &matrixRef = *(matrixPtr.get());
        for(int i=0; i<n; i++)
        {
            matrixRef.set(i, i, 1.0);
        }
        return matrixPtr;
    }

    /*! \return a Matrix of size r x c with only 1's
     */
    static std::unique_ptr<Matrix> ones(int r, int c)
    {
        assert(r >=0 && c>=0);
        auto copyPtr = std::unique_ptr<Matrix>(new Matrix(r, c));
        for(int i=0; i<r; i++)
        {
            for(int j=0; j<c; j++)
            {
                copyPtr->set(i, j, 1.0);
            }
        }
        return copyPtr;
    }

    /*! \return a Matrix of size [r x c] with randomized elements
     */
    static std::unique_ptr<Matrix> randMatrix(const int r, const int c)
    {
        assert(r > 0 && c > 0);
        srand(time(0));
        auto matrixPtr = std::unique_ptr<Matrix>(new Matrix(r, c));
        for(int i=0; i<r; i++)
        {
            for(int j=0; j<c; j++)
            {
                matrixPtr->set(i, j, rand());
            }
        }
        return matrixPtr;
    }

    static std::unique_ptr<Matrix> hammard(const Matrix &m0, const Matrix &m1)
    {
        assert(m0.rows()==m1.rows() && m0.cols()==m1.cols());

        auto r = m0.rows();
        auto c = m0.cols();
        auto copyPtr = std::unique_ptr<Matrix>(new Matrix(r, c));
        for(int i=0; i<r; i++)
        {
            for(int j=0; j<c; j++)
            {
                auto v0 = m0.get(i, j);
                auto v1 = m1.get(i, j);
                copyPtr->set(i, j, v0 * v1);
            }
        }
        return copyPtr;
    }

    static std::unique_ptr<Matrix> copy(const Matrix &m)
    {
        auto r = m.rows();
        auto c = m.cols();
        auto copyPtr = std::unique_ptr<Matrix>(new Matrix(r, c));
        for(int i=0; i<r; i++)
        {
            for(int j=0; j<c; j++)
            {
                copyPtr->set(i, j, m.get(i, j));
            }
        }
        return copyPtr;
    }

    static std::unique_ptr<Matrix> concatenate(const Matrix &m0, const Matrix &m1, int axis)
    {
        assert(axis==0 || axis==1);

        // concatenate matrices along the row axis
        if(axis==0)
        {
            assert(m0.cols() == m1.cols());
            int r = m0.rows() + m1.rows();
            int c = m0.cols();
            auto copyPtr = std::unique_ptr<Matrix>(new Matrix(r, c));
            for(int i=0; i<r; i++)
            {
                for(int j=0; j<c; j++)
                {
                    double val = i < m0.rows() ? m0.get(i, j) : m1.get(i - m0.rows(), j);
                    copyPtr->set(i, j, val );
                }
            }
            // return
            return copyPtr;
        }

        // concatenate matrices along the column axis
        else if(axis==1)
        {
            assert(m0.rows() == m1.rows());
            int r = m0.rows();
            int c = m0.cols() + m1.cols();
            auto copyPtr = std::unique_ptr<Matrix>(new Matrix(r, c));
            for(int i=0; i<r; i++)
            {
                for(int j=0; j<c; j++)
                {
                    double val = j < m0.cols() ? m0.get(i, j) : m1.get(i, j - m0.cols());
                    copyPtr->set(i, j, val);
                }
            }
            // return
            return copyPtr;
        }
    }
};

#endif // BOOST_MATRIX_ADAPTER_H
