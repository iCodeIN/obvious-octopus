#ifndef GAUSSIAN_ELIMINATION_H
#define GAUSSIAN_ELIMINATION_H

#include "matrix.hpp"

namespace matrix
{
    /*! In linear algebra, Gaussian elimination (also known as row reduction) is an algorithm
        for solving systems of linear equations. It is usually understood as a sequence of
       operations performed on the associated matrix of coefficients. This method can also be
       used to find the rank of a matrix, to calculate the determinant of a matrix, and to
       calculate the inverse of an invertible square matrix. The method is named after
       Carl Friedrich Gauss (1777–1855), although it was known to Chinese mathematicians as
       early as 179 CE.
    */
    class GaussianElimination final
    {
        public:
            /*! Prohibit construction of GaussianElimination. This class offers only static methods.
             */
            explicit GaussianElimination() = delete;

            /*! Performs row reduction on a matrix, using a sequence of elementary row operations to
            	 modify the matrix until the lower left-hand corner of the matrix is filled with zeros,
            	 as much as possible. There are three types of elementary row operations:
            	 - Swapping two rows,
            	 - Multiplying a row by a non-zero number,
            	 - Adding a multiple of one row to another row.

            	 Using these operations, a matrix can always be transformed into an upper triangular matrix,
            	 and in fact one that is in row echelon form.
             */
            static void gaussianElimination(Matrix &matrix);
    };
}

#endif // GAUSSIAN_ELIMINATION_H
