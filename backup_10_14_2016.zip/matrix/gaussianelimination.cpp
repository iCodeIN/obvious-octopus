#include "gaussianelimination.h"

#include "matrix.hpp"

using namespace matrix;

void GaussianElimination::gaussianElimination(Matrix& matrix)
{
    // Get to upper triangular form
    auto pivot = 0;
    while(pivot != matrix.rows())
    {

        // Find (absolute value) largest pivot
        double maxPivot = matrix.get(pivot, pivot);
        int maxPivotRow = pivot;
        for(int i=pivot; i<matrix.rows(); i++)
        {
            if(abs(matrix.get(pivot, pivot)) > maxPivot)
            {
                maxPivot = abs(matrix.get(i, pivot));
                maxPivotRow = i;
            }
        }
        // Swap rows to place pivot in correct position
        matrix.swapRows(pivot, maxPivotRow);

        // Divide each element in the row by the pivot
        double pivotValue = matrix.get(pivot, pivot);
        for(int i=pivot+1; i<matrix.cols(); i++)
        {
            matrix.set(pivot, i, matrix.get(pivot,i) / pivotValue);
        }
        matrix.set(pivot, pivot, 1.0);

        // Handle subsequent rows
        for(int i=pivot+1; i<matrix.rows(); i++)
        {
            double factor = matrix.get(i, pivot);
            for(int j = pivot + 1 ; j < matrix.cols() ; j++)
            {
                matrix.set(i, j, matrix.get(i, j) - matrix.get(pivot, j) * factor);
            }
            matrix.set(i, pivot, 0.0);

        }

        // Find next pivot
        pivot++;
    }

    // Backsubstitution
    pivot = matrix.rows() - 1;
    while(pivot > 0)
    {
        // Substitute this row in the rows above it
        for(int i=pivot-1; i>=0; i--)
        {
            double pivotValue = matrix.get(i, pivot);
            for(int j=0; j<matrix.cols(); j++)
            {
                matrix.set(i, j, matrix.get(i, j) - matrix.get(pivot, j) * pivotValue);
            }
        }
        // Find next pivot
        pivot--;
    }
}
