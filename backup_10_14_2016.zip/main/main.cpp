#include <iostream>
#include "matrix/matrix.hpp"

using namespace matrix;
using namespace std;

int main()
{
    // create matrix
    unique_ptr<IMatrix> m = unique_ptr<IMatrix>(new Matrix(5,5));

    // return
    return 0;
}
