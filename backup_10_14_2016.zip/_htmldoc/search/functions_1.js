var searchData=
[
  ['bktree',['BKTree',['../classtree_1_1BKTree.html#a46d58c492c64bad27b18e0bc2a98e356',1,'tree::BKTree']]]
];
