var searchData=
[
  ['weightedsampling',['WeightedSampling',['../classnumeric_1_1WeightedSampling.html',1,'numeric']]],
  ['word2vec',['Word2Vec',['../classNLP_1_1Word2Vec.html',1,'NLP']]]
];
