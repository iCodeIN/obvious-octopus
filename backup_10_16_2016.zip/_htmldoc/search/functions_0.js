var searchData=
[
  ['add',['add',['../classSVG_1_1SVG.html#a16a57a2cf338dc191b1382df380d7fdd',1,'SVG::SVG::add()'],['../classXML_1_1Element.html#a439b343b44d5627c25c8d86f21bd9730',1,'XML::Element::add()']]],
  ['addmatrix',['addMatrix',['../classplotting_1_1HeatPlot.html#a394c756f2da4e3d6ce3f41321f3671c3',1,'plotting::HeatPlot']]],
  ['addseries',['addSeries',['../classplotting_1_1AreaPlot.html#a5a107144c326def4d39ed5483fe4d9e2',1,'plotting::AreaPlot::addSeries()'],['../classplotting_1_1LinePlot.html#aacddebf243791d66224bf34b296cb7c5',1,'plotting::LinePlot::addSeries()']]],
  ['apply',['apply',['../classmatrix_1_1IMatrix.html#a101517507395c9f105feba61f0d1f8da',1,'matrix::IMatrix']]],
  ['areaplot',['AreaPlot',['../classplotting_1_1AreaPlot.html#a72ec077c33eda0fe3e7dacd7bb9ec908',1,'plotting::AreaPlot::AreaPlot(int w, int h)'],['../classplotting_1_1AreaPlot.html#a2cb6176fc63e89b4983571e95fc9aef5',1,'plotting::AreaPlot::AreaPlot(AreaPlot &amp;n)=delete'],['../classplotting_1_1AreaPlot.html#a08aff0d910bafd34c919893043cceb0b',1,'plotting::AreaPlot::AreaPlot(const AreaPlot &amp;n)=delete']]]
];
