var searchData=
[
  ['defaultgraphrenderer',['DefaultGraphRenderer',['../classgraphUI_1_1DefaultGraphRenderer.html',1,'graphUI']]],
  ['derivative',['Derivative',['../classnumeric_1_1Derivative.html',1,'numeric']]],
  ['dft',['DFT',['../classnumeric_1_1DFT.html',1,'numeric']]],
  ['digits',['Digits',['../classnumeric_1_1Digits.html',1,'numeric']]]
];
