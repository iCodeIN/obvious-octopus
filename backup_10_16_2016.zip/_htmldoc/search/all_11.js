var searchData=
[
  ['univariatefunctiontype',['UnivariateFunctionType',['../classmeta_1_1AbstractMetaHeuristic.html#a617de3eec4cc125828cb18439ff2234b',1,'meta::AbstractMetaHeuristic']]]
];
