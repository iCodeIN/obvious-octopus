var searchData=
[
  ['preserveaspectratio',['PreserveAspectRatio',['../classSVG_1_1SVG.html#adad70e278302823bd721b3f23bacfdff',1,'SVG::SVG']]]
];
