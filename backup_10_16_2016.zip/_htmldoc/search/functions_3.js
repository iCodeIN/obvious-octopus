var searchData=
[
  ['defaultgraphrenderer',['DefaultGraphRenderer',['../classgraphUI_1_1DefaultGraphRenderer.html#a587e4b1d1cf31c834346644e5da42a1f',1,'graphUI::DefaultGraphRenderer']]],
  ['depth',['depth',['../classtree_1_1BKTree.html#a9772099cc621400c12ee33bd20bd0099',1,'tree::BKTree']]],
  ['derivative',['Derivative',['../classnumeric_1_1Derivative.html#a5dfe768e4ca8617554ff952df0dda006',1,'numeric::Derivative::Derivative()=delete'],['../classnumeric_1_1Derivative.html#acd7e0c9caea7e5536288e3b7470115a9',1,'numeric::Derivative::derivative(const RealFunctionType &amp;f)']]],
  ['dft',['DFT',['../classnumeric_1_1DFT.html#acccd34ffdc8ecc474e79954b6c935b23',1,'numeric::DFT']]],
  ['digitalroot',['digitalRoot',['../classnumeric_1_1Digits.html#a225d22829fb051225b7d5d27fcf0e971',1,'numeric::Digits']]],
  ['digits',['digits',['../classnumeric_1_1Digits.html#aa2afcfe9f2c6b4f29cf2a950d78fb721',1,'numeric::Digits']]]
];
