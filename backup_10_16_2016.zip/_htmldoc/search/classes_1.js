var searchData=
[
  ['bktree',['BKTree',['../classtree_1_1BKTree.html',1,'tree']]],
  ['boostmatriximpl',['BoostMatrixImpl',['../classmatrix_1_1BoostMatrixImpl.html',1,'matrix']]]
];
