var searchData=
[
  ['realfunctiontype',['RealFunctionType',['../classnumeric_1_1Derivative.html#a9ae94b40e81041335af21a764eceaa19',1,'numeric::Derivative']]],
  ['rgbcolor',['RGBColor',['../classSVG_1_1HSV.html#a93da59189b0174379bf7033229c8096d',1,'SVG::HSV']]]
];
