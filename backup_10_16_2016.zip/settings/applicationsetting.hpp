#pragma once
#ifndef APPLICATIONSETTING_HPP
#define APPLICATIONSETTING_HPP

#include <assert.h>
#include <map>
#include <string>

namespace general
{
    class ApplicationSetting
    {
        public:

            /*!
             */
            static void set(int argc, char** argv)
            {
                // parse all command line arguments
                for(int i=0; i<argc; i++)
                {
                    auto setting = std::string(argv[i]);
                    auto splitPos = setting.find("=");
                    auto key = setting.substr(0, splitPos);
                    auto val = (splitPos != std::string::npos) ? setting.substr(splitPos) : "";
                    ApplicationSetting::set(key, val);
                }
            }

            /*!
             */
            static bool isSet(const std::string &key)
            {
                return m_settingsValues.find(key) != m_settingsValues.end();
            }

            /*!
             */
            static const std::string get(const std::string &key)
            {
                assert(isSet(key));
                return m_settingsValues.find(key)->second;
            }

            /*!
             */
            static void set(const std::string &key, const std::string &value)
            {
                assert(!isSet(key));
                m_settingsValues[key] = value;
            }

        private:
            // --- members ---
            static std::map<std::string, std::string>   ApplicationSetting::m_settingsValues;
    };
}

#endif // APPLICATIONSETTING_HPP