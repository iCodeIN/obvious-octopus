#include <fstream>
#include <iostream>
#include <string>
#include <tuple>
#include <vector>
#include <stdlib.h>
#include <memory>

#include "meta/assignmentsearch.hpp"
#include "meta/tabusearch.hpp"

using namespace std;

using TraineeshipInfoType = tuple<string, string, int>;                                            // location, speciality, period
using PreferenceInfoType = tuple<string, string, vector<string>, vector<string>, vector<int>>;     // name, firstname, location (love -> hate), speciality (love -> hate), period (love -> hate)

int NOF_LOCATIONS    = 4;
int NOF_SPECIALITY   = 4;
int NOF_PERIODS      = 4;

double LOCATION_WEIGHT = 25;
double SPECIALITY_WEIGHT = 65;
double PERIODS_WEIGHT = 99;

vector<string> split(const string &s, char t)
{
    vector<string> retval;
    string temp = "";
    for(int i=0; i<s.size(); i++)
    {
        if(s[i] == t)
        {
            if(temp.size() != 0)
            {
                retval.push_back(temp);
            }
            temp = "";
        }
        else
        {
            temp += s[i];
        }
    }
    if(temp.size() != 0)
    {
        retval.push_back(temp);
    }
    return retval;
}

int makeDemoFiles()
{
    string firstNames[10] = {"Jean-Alexandre", "Claude", "Louis", "Bob", "Nico", "Nicolas", "Quentin", "Maria", "Daniella", "Jeannine"};
    string lastNames[11] = {"Ptit", "LeGrand", "Jambon", "DuFromage","Dolor", "Lorem", "Ipsum", "Amet", "Descamps","Lachat", "Daniel"};

    string locations[4] = {"Paris", "Dijon", "Toulouse", "Ghent"};
    string specialities[4] = {"surgery", "pediatry", "internal_medicine","gyneacology"};
    int periods[] = {1,2,3,4};

    int nrOfStudents = 64;
    int nrOfLocations = 80;

    // 1. generate traineeships
    ofstream tFile;
    tFile.open("traineeships.txt");
    for(int i=0; i<nrOfLocations; i++)
    {
        int k = nrOfLocations / (sizeof(locations) / sizeof(locations[0]));
        for(int j = 0; j<k; j++)
        {
            tFile << locations[i/k] << "\t\t" << specialities[rand() % (sizeof(specialities) / sizeof(specialities[0]))] << "\t\t" << periods[rand() % (sizeof(periods) / sizeof(periods[0]))] << std::endl;
        }
    }
    tFile.close();

    // 2. generate students
    ofstream sFile;
    sFile.open("student_preferences.txt");
    for(int i=0; i<nrOfStudents; i++)
    {
        sFile << firstNames[rand() % (sizeof(firstNames)/sizeof(firstNames[0]))] << "\t\t" << lastNames[rand() % (sizeof(lastNames)/sizeof(lastNames[0]))];
    }
    sFile.close();

}

int solve()
{
    // 1. get file containing traineeships
    cout << "please enter traineeships : ";
    string tFile = "";
    cin >> tFile;

    // 2. get file containing preferences
    cout << "please enter preferences   : ";
    string pFile = "";
    cin >> pFile;

    // 3. get solver time constraints

    // 4. process traineeships file
    vector<TraineeshipInfoType> traineeships;
    string line = "";
    ifstream tIs(tFile);
    while(getline(tIs, line))
    {
        auto fields = split(line, '\t');
        auto location     = fields[0];
        auto speciality   = fields[1];
        auto period       = atoi(fields[2].c_str());
        auto nofPlaces    = atoi(fields[3].c_str());
        for(int i=0; i<nofPlaces; i++)
        {
            traineeships.push_back(make_tuple(location, speciality, period));
        }
    }
    tIs.close();

    // 5. process file containing preferences
    vector<PreferenceInfoType> preferences;
    ifstream pIs(pFile);
    while(getline(pIs, line))
    {
        auto fields = split(line, '\t');
        auto name = fields[0];
        auto firstname = fields[1];

        auto locationPref = vector<string>();
        auto pos = fields.begin() + 2;
        copy(pos, pos + NOF_LOCATIONS, locationPref.begin());

        auto specialityPref = vector<string>();
        pos = pos + NOF_LOCATIONS;
        copy(pos, pos + NOF_SPECIALITY, specialityPref.begin());

        auto periodTempPref = vector<string>();
        pos = pos + NOF_SPECIALITY;
        copy(pos, pos + NOF_PERIODS, periodTempPref.begin());

        auto periodPref = vector<int>();
        for(auto p : periodTempPref)
        {
            periodPref.push_back(atoi(p.c_str()));
        }

        preferences.push_back(make_tuple(name, firstname, locationPref, specialityPref, periodPref));
    }
    pIs.close();

    // 6. define metric
    auto m = [&traineeships, &preferences](int s, int t)
    {
        if(t == -1)
        {
            return 0;
        }
        auto preference = preferences[s];
        auto traineeship = traineeships[t];

        auto &lPrefs = get<2>(preference);
        auto &sPrefs = get<3>(preference);
        auto &pPrefs = get<4>(preference);

        double f0 = (int) lPrefs.size() - (int) (lPrefs.begin() - find(lPrefs.begin(), lPrefs.end(), get<0>(traineeship)));
        double f1 = (int) sPrefs.size() - (int) (sPrefs.begin() - find(sPrefs.begin(), sPrefs.end(), get<1>(traineeship)));
        double f2 = (int) pPrefs.size() - (int) (pPrefs.begin() - find(pPrefs.begin(), pPrefs.end(), get<2>(traineeship)));

        return (int) (f0 *  LOCATION_WEIGHT + f1 * SPECIALITY_WEIGHT + f2 * PERIODS_WEIGHT);
    };

    // 7. unleash solver
    auto innerSearch = std::unique_ptr<meta::AbstractMetaHeuristic>(new meta::TabuSearch());
    auto search = meta::AssignmentSearch(std::move(innerSearch));
    auto bestSolution = search.findIntMin(m, preferences.size(), traineeships.size(), 1000);

    // 8. print solution
    for(int i=0; i<bestSolution.size(); i++)
    {
        auto p = preferences[i];
        auto t = traineeships[bestSolution[i]];
        cout << get<0>(p) << " " << get<1>(p) << " : " << get<0>(t) << " - " << get<1>(t) << " - " << get<2>(t) << endl;
    }

    return 0;
}

int main()
{
    makeDemoFiles();
}
