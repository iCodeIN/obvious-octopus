#ifndef TURINGMACHINE_HPP
#define TURINGMACHINE_HPP

namespace turing
{
    class TuringMachine
    {
        public:
        private:
    };
}

#endif // TURINGMACHINE_HPP
