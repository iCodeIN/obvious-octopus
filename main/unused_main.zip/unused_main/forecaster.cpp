#include "numeric/dft.hpp"
#include "smooth/expsmooth.hpp"
#include "smooth/polysmooth.hpp"
#include "plotting/lineplot.hpp"
#include "svg/svg.hpp"

#include <fstream>
#include <iostream>
#include <memory>
#include <string>
#include <vector>

#define DEBUG 0

using namespace std;
using namespace plotting;
using namespace numeric;
using namespace smooth;

int main()
{
    // 1. read data
    if(DEBUG)
    {
        std::cout << "1. read data" << std::endl;
    }
    ifstream inputFile("/home/joris/Desktop/data/monthly_milk_production_pounds_per_cow_jan_62_dec_75.txt");

    string line;
    vector<double> xs;
    while(getline(inputFile, line))
    {
        // skip comments
        if(line[0]=='#')
        {
            continue;
        }
        xs.push_back(atof(line.c_str()));
    }

    // 2. determine period-length
    if(DEBUG)
    {
        std::cout << "2. determine period length" << std::endl;
    }
    auto periods = DFT::sortedDFT(xs);
    auto period = xs.size();
    for(auto p : periods)
    {
        if(p != 0.0 && p != xs.size())
        {
            period = p;
            break;
        }
    }

    // 3. determine average period
    if(DEBUG)
    {
        std::cout << "3. determine average period [" << period << "]" << std::endl;
    }
    auto nrOfPeriods = (xs.size() / period);
    std::vector<double> avgPeriod;
    for(int i=0; i<period; i++)
    {
        avgPeriod.push_back(0.0);
    }
    for(int i=0; i<nrOfPeriods*period; i++)
    {
        avgPeriod[i%period] += xs[i] / nrOfPeriods;
    }

    // 4. perform smoothing
    if(DEBUG)
    {
        std::cout << "4. perform smoothing" << std::endl;
    }
    avgPeriod = ExponentialSmoothing::smooth(avgPeriod, 0.8);

    // 5. calculate remaining error
    if(DEBUG)
    {
        std::cout << "5. calculate remaining error" << std::endl;
    }
    std::vector<std::pair<double,double>> err;
    for(int i=0; i<xs.size(); i++)
    {
        err.push_back(std::make_pair(i, xs[i] - avgPeriod[i%period]));
    }

    // 6. fit polynomial to error
    if(DEBUG)
    {
        std::cout << "6. fit polynomial to error" << std::endl;
    }
    auto poly = PolynomialSmoothing::fit(err, 10);

    // 7. include polynomial trend in evaluation function
    if(DEBUG)
    {
        std::cout << "7. include polynomial trend in evaluation function" << std::endl;
    }
    auto eval = [&avgPeriod, &poly](int k)
    {
        auto bsePrediction = avgPeriod[k % avgPeriod.size()];
        auto errPrediction = 0.0;
        for(int i=0; i<poly.size(); i++)
        {
            errPrediction += pow(k, i) * poly[i];
        }
        return bsePrediction + errPrediction;
    };

    // 8. measure performance
    if(DEBUG)
    {
        std::cout << "8. measure performance" << std::endl;
    }
    double avgValue = 0.0;
    double avgError = 0.0;
    for(int i=0; i<xs.size(); i++)
    {
        avgValue += xs[i];
        avgError += abs(xs[i] - eval(i));
        if(DEBUG)
        {
            std::cout << xs[i] << "\t" << eval(i) << "\t" << abs(xs[i] - eval(i)) << std::endl;
        }
    }
    avgValue /= xs.size();
    avgError /= (xs.size() * avgValue);

    // 9. Plotting
    if(DEBUG)
    {
        std::cout << "8. measure performance" << std::endl;
    }
    auto plot = std::unique_ptr<LinePlot>(new LinePlot(1000,500));
    std::vector<std::pair<double,double>> plot0;
    std::vector<std::pair<double,double>> plot1;
    std::vector<std::pair<double,double>> plot2;
    for(int i=0; i<xs.size(); i++)
    {
        plot0.push_back(std::make_pair(i, xs[i]));
        plot1.push_back(std::make_pair(i, eval(i)));
        plot2.push_back(std::make_pair(i, xs[i] - eval(i)));
    }
    plot.get()->addSeries(plot0);
    plot.get()->addSeries(plot1);
    plot.get()->addSeries(plot2);
    auto svg = plot.get()->render();

    // 10. Output average error
    if(DEBUG)
    {
        std::cout << "9. Avg. Error : " << avgError << std::endl;
    }

    std::cout << *(svg.get()) << std::endl;

    return 0;
}
