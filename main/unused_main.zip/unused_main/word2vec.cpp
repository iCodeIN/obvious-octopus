#include "nlp/word2vec.hpp"

#include <string>
#include <vector>
#include <iostream>

using namespace NLP;
using namespace std;

int main_word2vec()
{
    vector<string> v;
    v.push_back("my");
    v.push_back("bonny");
    v.push_back("is");
    v.push_back("over");
    v.push_back("the");
    v.push_back("ocean");
    v.push_back("my");
    auto unigramGetter = [&v](int sample, int index) -> string& { return v[index]; };
    auto sampleSizeGetter = [&v](int sample) -> int {return v.size();};

    for(int i=0; i<v.size(); i++)
    {
        for(int j=0; j<v.size(); j++)
        {
            auto &r0 = unigramGetter(0, i);
            auto &r1 = unigramGetter(0, j);
            std::cout << r0 << "\t" << r1 << "\t" << (r0 == r1) << std::endl;
        }
    }

    Word2Vec<string> w2v {unigramGetter, sampleSizeGetter, 1};
}
