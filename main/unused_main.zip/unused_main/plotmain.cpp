#include <iostream>
#include <math.h>
#include <vector>

#include "matrix/matrix.hpp"

#include "svg/svg.hpp"
#include "plotting/heatplot.hpp"

using namespace Plotting;

int main_plotting()
{

    std::unique_ptr<Matrix::MatrixType> m = Matrix::randMatrix(100,100);
    auto &mRef = *(m.get());

    std::function<double(int,int)> value = [&](int i, int j)
    {
        return Matrix::get(mRef, i, j);
    };

    auto plot = std::unique_ptr<HeatPlot>(new HeatPlot(400,400));
    auto &plotRef = *(plot.get());
    plotRef.addMatrix(value, 100, 100);

    auto svg = plotRef.render();
    auto &svgRef = *(svg.get());

    std::cout << svgRef << std::endl;

    return 0;
}
