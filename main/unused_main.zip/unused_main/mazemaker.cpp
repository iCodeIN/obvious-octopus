#include "maze/maze.h"
#include "maze/mazedrawer.h"

#include "svg/svg.hpp"

#include <iostream>

using namespace SVG;

int main_mazemaker()
{
    auto maze = std::unique_ptr<Maze>(new Maze(25, 25));
    auto &m = *(maze.get());

    auto svg = MazeDrawer::render(m);

    std::cout << *(svg.get()) << std::endl;

    return 0;
}
