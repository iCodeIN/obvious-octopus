#include "ai/neuralnetwork.h"
#include "matrix/matrix.hpp"

#include <iostream>
#include <math.h>


int main_neural()
{
    std::vector<int> d;
    d.push_back(2);
    d.push_back(3);
    d.push_back(3);
    d.push_back(1);
    auto nnet = std::unique_ptr<AI::NeuralNetwork>(new AI::NeuralNetwork(d));

    auto x = Matrix::randMatrix(4,2);
    auto xRef = *(x.get());
    Matrix::set(xRef, 0, 0, 0);
    Matrix::set(xRef, 0, 0, 0);
    Matrix::set(xRef, 1, 0, 0);
    Matrix::set(xRef, 1, 0, 1);
    Matrix::set(xRef, 2, 0, 1);
    Matrix::set(xRef, 2, 0, 0);
    Matrix::set(xRef, 3, 0, 1);
    Matrix::set(xRef, 3, 0, 1);

    auto y = Matrix::randMatrix(4,1);
    auto yRef = *(y.get());
    Matrix::set(yRef, 0, 0, 0);
    Matrix::set(yRef, 1, 0, 1);
    Matrix::set(yRef, 2, 0, 1);
    Matrix::set(yRef, 3, 0, 0);

    nnet.get()->feedforward(xRef);
    nnet.get()->backpropagate(xRef, yRef);

    std::cout << Matrix::rows(yRef) << "x" << Matrix::cols(yRef) << std::endl;

    return 0;
}


/*
int main()
{
   auto i = Matrix::eye(4);
   auto iRef = *(i.get());
   auto y = Matrix::mul(iRef,iRef);
   auto yRef = *(y.get());

   for(int i=0;i<Matrix::rows(yRef);i++)
   {
      for(int j=0;j<Matrix::cols(yRef);j++)
      {
         std::cout << (j==0 ? "" : ", ") << Matrix::get(yRef, i, j);
      }
      std::cout << std::endl;
   }
}
*/
