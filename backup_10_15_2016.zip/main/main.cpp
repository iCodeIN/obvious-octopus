#include <iostream>
#include "matrix/boostmatriximpl.hpp"

using namespace matrix;
using namespace std;

int main_unused()
{
    // create matrix
    unique_ptr<IMatrix> m = unique_ptr<IMatrix>(new BoostMatrixImpl(5,5));

    // return
    return 0;
}
