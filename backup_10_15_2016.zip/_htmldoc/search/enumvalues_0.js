var searchData=
[
  ['none',['NONE',['../classSVG_1_1SVG.html#adad70e278302823bd721b3f23bacfdffaf828cdb9af710c522098aa8251a1ce21',1,'SVG::SVG']]]
];
