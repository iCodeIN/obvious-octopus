var searchData=
[
  ['metrictype',['MetricType',['../classtree_1_1BKTree.html#aa33586b67ade92e0423c38386e25f94e',1,'tree::BKTree']]]
];
