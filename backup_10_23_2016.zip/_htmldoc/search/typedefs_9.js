var searchData=
[
  ['seriestype',['SeriesType',['../classplotting_1_1AreaPlot.html#a4dfddf98a045726fa1b32d7381c18094',1,'plotting::AreaPlot::SeriesType()'],['../classplotting_1_1LinePlot.html#a58e3679d171917f9b6f0fa058d3f4ffc',1,'plotting::LinePlot::SeriesType()'],['../classsmooth_1_1PolynomialSmoothing.html#a5762c5126f3e04a7ac1321198ba03db3',1,'smooth::PolynomialSmoothing::SeriesType()']]],
  ['sizefunctiontype',['SizeFunctionType',['../classgraphUI_1_1AbstractGraphLayout.html#ae84a2c963b5b39e97acf98114c2de64a',1,'graphUI::AbstractGraphLayout']]],
  ['sizetype',['SizeType',['../classgraphUI_1_1AbstractGraphLayout.html#a53dd856bd3bc74960974e613f1ffe4d1',1,'graphUI::AbstractGraphLayout']]]
];
