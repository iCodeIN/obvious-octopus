var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../classSVG_1_1IElement.html#a4b8fdacb65b595c3a32b7bac1075c42a',1,'SVG::IElement::operator&lt;&lt;()'],['../classXML_1_1BoostElementImpl.html#a77d5f499338c70b8a974fe3db5a6efdb',1,'XML::BoostElementImpl::operator&lt;&lt;()']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../classXML_1_1BoostElementImpl.html#a04a59e89a10f531d7f71b381bf3013fa',1,'XML::BoostElementImpl']]]
];
